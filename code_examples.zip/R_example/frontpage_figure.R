### Initialize document
# Load libraries
library(tidyverse)

# Set working directory
setwd("~/JDJG/")

# Load data
load("~/NNEDL/masterprojectxjdjg/curated/Mouse_studies/curated_data_mouse_2.RData") # should of course load the NNEDL version
load("~/JDJG/data/curated/trans_dge.RData")
load("~/JDJG/data/curated/soma_human.RData")



################################################################################
#################### FIGURE 7: Volcano, precision, overlap #####################
################################################################################
for (generate_figure in "FIGURE_7"){
  
  ## Volcano plot, SomaHuman2, intra-study
  source("~/JDJG/code/volcano_function_human.R")
  volc <- volcano_plot(df1 = 2, short_title = TRUE, frontpage = TRUE)
  
  ## CV plot
  source("~/JDJG/scripts/CV_plot_function.R")
  cv <- cv_plot(soma1 = init_JYNR210602, soma2 = init_JYNR220601,
          meta1 = init_meta_JYNR210602, meta2 = init_meta_JYNR220601,
          frontpage = TRUE)
    
  ## PCA
  source("~/JDJG/scripts/pca.R")
  pca <- pcaplot(limma_data, point_size = 5, colour = "Treatment", frontpage = TRUE)
  
  ## Bland-Altman Plot
  source("~/JDJG/scripts/bland_altman_function.R")
  ba <- bland_altman(frontpage = TRUE)
  
  ## Putting it all together
  fp_fig <- ggarrange(ba,pca,volc,cv,
            nrow = 2, ncol = 2)
  
  ggsave("figures/fp_fig.png", plot = fp_fig, width = 1.5*(210-20), height = 1.5*(297-30)*0.5,
         units = "mm", dpi = 185, bg = "white")
}